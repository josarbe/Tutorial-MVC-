# MVCdotnet
se creo una aplicación web con asp.net con la arquitectura MVC, basado del tutorial de Microsoft 
